//App42 C# SDK
1. UnZip the downloaded file
2. This will contain App42_CSharp_SDK_x.x.x.dll, CSharp_Cloud_API_Guide.pdf, doc, lib, sample folder and README.txt
3. doc folder contains API docs
4. Sample folder contains Visual Studio C# sample project for using App42 C# SDK.
5. lib folder contains the external dll files used for developing the sample app.
5. You need to put App42_CSharp_SDK_x.x.x.dll in classpath of your Project to use this.
6. Please visit http://api.shephertz.com/cloudapidocs/index.php for detail documentaion.