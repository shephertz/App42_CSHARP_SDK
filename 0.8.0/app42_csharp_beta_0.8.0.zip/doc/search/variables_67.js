var searchData=
[
  ['gamename',['gameName',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1csharp_1_1reward_1_1_reward.html#a829138697d56a2827f29e7df7e8ec610',1,'com::shephertz::app42::paas::sdk::csharp::reward::Reward']]]
];
