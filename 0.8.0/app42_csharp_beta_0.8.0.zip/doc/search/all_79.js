var searchData=
[
  ['y',['y',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1csharp_1_1image_processor_1_1_image.html#a183d8590a886d48b166346d0202123fe',1,'com::shephertz::app42::paas::sdk::csharp::imageProcessor::Image']]]
];
