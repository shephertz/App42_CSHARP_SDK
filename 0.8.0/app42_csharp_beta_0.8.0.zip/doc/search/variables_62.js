var searchData=
[
  ['binary',['BINARY',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1csharp_1_1upload_1_1_upload_file_type.html#a6353819209208be9af6c28b18c05b3ce',1,'com::shephertz::app42::paas::sdk::csharp::upload::UploadFileType']]],
  ['body',['body',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1csharp_1_1email_1_1_email.html#a0b929ddaee0169051957af7fa20a5478',1,'com::shephertz::app42::paas::sdk::csharp::email::Email']]]
];
