var searchData=
[
  ['rank',['rank',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1csharp_1_1game_1_1_game_1_1_score.html#a6c905044b01954e64f1b41d7dc04d30b',1,'com::shephertz::app42::paas::sdk::csharp::game::Game::Score']]],
  ['rating',['rating',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1csharp_1_1review_1_1_review.html#a5c6b95e7e6d97117a40ea4f7485d8fe5',1,'com::shephertz::app42::paas::sdk::csharp::review::Review']]],
  ['recommendeditemlist',['recommendedItemList',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1csharp_1_1recommend_1_1_recommender.html#aeb7f4d8b9e2a0d22f6c76f4478455d4a',1,'com::shephertz::app42::paas::sdk::csharp::recommend::Recommender']]],
  ['reviewid',['reviewId',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1csharp_1_1review_1_1_review.html#a86174baa21a0c5138969ccfa17716ae3',1,'com::shephertz::app42::paas::sdk::csharp::review::Review']]],
  ['rolelist',['roleList',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1csharp_1_1user_1_1_user.html#a016af549473b41cba17df142d7b7f1f8',1,'com::shephertz::app42::paas::sdk::csharp::user::User']]]
];
