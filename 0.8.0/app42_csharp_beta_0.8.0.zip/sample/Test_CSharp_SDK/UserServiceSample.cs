﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using com.shephertz.app42.paas.sdk.csharp;
using com.shephertz.app42.paas.sdk.csharp.user;


namespace Test_CSharp_SDK
{
    class UserServiceSample
    {
        ///<summary> 
        ///Main Method To Create App42 User on Cloud.
        ///</summary>
        ///<param name=args>args</param>

        static void Main(string[] args)
        {
            CreateUser();
        }
        /// <summary>
        /// Test Method for creating the User in App42 Cloud. 
        /// </summary>
        public static void CreateUser()
        {
            /// Enter your Public Key and Private Key Here in Constructor. You can
            /// get it once you will create a app in app42 console.

            ServiceAPI sp = new ServiceAPI("23313e1e2142e282372d8015f616f0da3a3767b5ea665bcb76779aeb939a046", 
                "23355cd1512a97351b34bccf59e638f8555e7d801f330c1aa15fca7d9e6a55da6");

            /// Create Instance of User Service
            UserService userService = sp.BuildUserService();
            User user = null;
            /// Create user or call other available method on the user service
            /// reference
            try
            {
                user = userService.CreateUser("Nick", "test",
                        "nick@shephertz.com");
            }
            catch (App42BadParameterException ex)
            {

                /// Exception Caught
                /// Check if User already Exist by checking app error code
                if (ex.GetAppErrorCode() == 2001)
                {
                    Console.WriteLine("App42BadParameterException : " + ex.GetAppErrorCode());
                    /// Do exception Handling for Already created User.
                }
            }
            catch (App42SecurityException ex)
            {
                /// Exception Caught
                /// Check for authorization Error due to invalid Public/Private Key
                if (ex.GetAppErrorCode() == 1401)
                {
                    /// Do exception Handling here
                    Console.WriteLine("App42SecurityException : " + ex.GetAppErrorCode());
                }
            }
            catch (App42Exception ex)
            {
                /// Exception Caught due to other Validation
            }
            /// Render the object response. This will return the Successful created
            /// User response
            Console.WriteLine(user.GetUserName());
            Console.WriteLine(user.GetPassword());
            Console.WriteLine(user.GetEmail());
            Console.ReadLine();
        }
    }
}

