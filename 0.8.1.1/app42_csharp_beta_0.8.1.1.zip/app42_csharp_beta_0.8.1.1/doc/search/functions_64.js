var searchData=
[
  ['debug',['Debug',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1csharp_1_1_app42_log.html#a62332d48f53fceb9361b2c6f2ede418e',1,'com.shephertz.app42.paas.sdk.csharp.App42Log.Debug()'],['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1csharp_1_1log_1_1_log_service.html#aa5c6b747b666620e40f323db520a306a',1,'com.shephertz.app42.paas.sdk.csharp.log.LogService.Debug()']]],
  ['decreasequantity',['DecreaseQuantity',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1csharp_1_1shopping_1_1_cart_service.html#acc0d487b2ad166946d408242dc00dabd',1,'com::shephertz::app42::paas::sdk::csharp::shopping::CartService']]],
  ['deductscore',['DeductScore',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1csharp_1_1game_1_1_score_service.html#a31a4ae34a0de4d391b20413b857d479a',1,'com::shephertz::app42::paas::sdk::csharp::game::ScoreService']]],
  ['deleteallpreferences',['DeleteAllPreferences',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1csharp_1_1recommend_1_1_recommender_service.html#afa3df0a82ea8620a849a82182344be21',1,'com::shephertz::app42::paas::sdk::csharp::recommend::RecommenderService']]],
  ['deletedocumentbyid',['DeleteDocumentById',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1csharp_1_1storage_1_1_storage_service.html#aec973386c0ac6141f7444a7424edbb1d',1,'com::shephertz::app42::paas::sdk::csharp::storage::StorageService']]],
  ['deletepullqueue',['DeletePullQueue',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1csharp_1_1message_1_1_queue_service.html#ab3e4fef552d3a5a3e359fe19513ad8b9',1,'com::shephertz::app42::paas::sdk::csharp::message::QueueService']]],
  ['deletestorage',['DeleteStorage',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1csharp_1_1geo_1_1_geo_service.html#acf8edcd86b50604ce5f432d73c69eb0b',1,'com::shephertz::app42::paas::sdk::csharp::geo::GeoService']]],
  ['deleteuser',['DeleteUser',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1csharp_1_1user_1_1_user_service.html#a7dc82fd5b945f05bb96e62d49bbdc7c7',1,'com::shephertz::app42::paas::sdk::csharp::user::UserService']]]
];
