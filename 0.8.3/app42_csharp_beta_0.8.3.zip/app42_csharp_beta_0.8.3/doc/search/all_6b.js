var searchData=
[
  ['kb',['KB',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1csharp_1_1app_tab_1_1_bandwidth_unit.html#a3dc7129855502e0e3f6618b1b392fd40',1,'com.shephertz.app42.paas.sdk.csharp.appTab.BandwidthUnit.KB()'],['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1csharp_1_1app_tab_1_1_storage_unit.html#a3dc7129855502e0e3f6618b1b392fd40',1,'com.shephertz.app42.paas.sdk.csharp.appTab.StorageUnit.KB()']]]
];
