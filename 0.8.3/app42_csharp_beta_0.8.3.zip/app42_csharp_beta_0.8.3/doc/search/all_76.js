var searchData=
[
  ['validatehowmany',['ValidateHowMany',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1csharp_1_1util_1_1_util.html#a9709fe4da9344e57efd1ee552c4638fb',1,'com::shephertz::app42::paas::sdk::csharp::util::Util']]],
  ['validatemax',['ValidateMax',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1csharp_1_1util_1_1_util.html#a25b7bf1379046fcda0132dfc8c2d30ce',1,'com::shephertz::app42::paas::sdk::csharp::util::Util']]],
  ['validatepackageusage',['ValidatePackageUsage',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1csharp_1_1app_tab_1_1_charge_service.html#a83fe6717fde7759258e3cd53a6768aa0',1,'com::shephertz::app42::paas::sdk::csharp::appTab::ChargeService']]],
  ['value',['value',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1csharp_1_1game_1_1_game_1_1_score.html#abfbfbcc9597c4acd284e0503be0f6528',1,'com.shephertz.app42.paas.sdk.csharp.game.Game.Score.value()'],['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1csharp_1_1recommend_1_1_recommender_1_1_recommended_item.html#abfbfbcc9597c4acd284e0503be0f6528',1,'com.shephertz.app42.paas.sdk.csharp.recommend.Recommender.RecommendedItem.value()'],['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1csharp_1_1session_1_1_session_1_1_attribute.html#a32147dacf0dd0bda3c39144c67347bf3',1,'com.shephertz.app42.paas.sdk.csharp.session.Session.Attribute.value()']]],
  ['video',['VIDEO',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1csharp_1_1upload_1_1_upload_file_type.html#ae36be83a73d2448c2f28284a66cf8bd1',1,'com::shephertz::app42::paas::sdk::csharp::upload::UploadFileType']]]
];
