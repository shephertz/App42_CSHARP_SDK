var searchData=
[
  ['width',['width',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1csharp_1_1image_processor_1_1_image.html#a9f4dbb0ebda41cb89051593801b905bd',1,'com::shephertz::app42::paas::sdk::csharp::imageProcessor::Image']]],
  ['wp7',['WP7',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1csharp_1_1push_notification_1_1_device_type.html#a13125b435a668656074eda4664918f29',1,'com::shephertz::app42::paas::sdk::csharp::pushNotification::DeviceType']]]
];
