﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using com.shephertz.app42.paas.sdk.csharp; 
using com.shephertz.app42.paas.sdk.csharp.user;

namespace Test_CSharp_SDK
{
    class Program
    {
        static void Main(string[] args) 
        {
            CreateUser();
        }


        /// <summary>
        /// Test Method for Creating User
        /// </summary>
        public static void CreateUser()
        {
            // Enter your Public Key and Private Key Here in Constructor. You can
            // get it once you will create a app in app42 console
            ServiceAPI sp = new ServiceAPI(
                    "f840228ccb231e3b29fefe2c1a23ccc4f10852cb60bc5753b4e8e3a35d1905cd",
                    "72ad18b585d355229cc0c0b999d1fafd25861d646c8fc66d378c65381c6616c0");
            // Create Instance of User Service
            User user = sp.BuildUser();
            String response = null;
            // create user or call other available method on the user service
            // reference
            try
            {
                response = user.CreateUser("test.app.123", "67899",
                        "test.app@shephertz.com");
            }
            catch (App42BadParameterException ex) 
            {
              
                // Exception Caught
                // Check if User already Exist by checking app error code
                if (ex.GetAppErrorCode() == 2001) 
                {
                    Console.WriteLine("App42BadParameterException : " + ex.GetAppErrorCode());
                    // Do exception Handling for Already created User.
                }
            }
            catch (App42SecurityException ex)
            {
                // Exception Caught
                // Check for authorization Error due to invalid Public/Private Key
                if (ex.GetAppErrorCode() == 1401)
                {
                    // Do exception Handling here
                    Console.WriteLine("App42SecurityException : " + ex.GetAppErrorCode());
                }
            }
            catch (App42Exception ex)
            {
                // Exception Caught due to other Validation
            }
            // Render the JSON response. This will return the Successful created
            // User response
            Console.WriteLine(response);
            Console.ReadKey();


        }
    }
}
