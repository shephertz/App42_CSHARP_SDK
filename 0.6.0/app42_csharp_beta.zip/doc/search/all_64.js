var searchData=
[
  ['deletepreferencefile',['DeletePreferenceFile',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1csharp_1_1recommend_1_1_recommender.html#a554738bd03ebba3ee6e140213bc26525',1,'com::shephertz::app42::paas::sdk::csharp::recommend::Recommender']]],
  ['deleteuser',['DeleteUser',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1csharp_1_1user_1_1_user.html#a5910398f9fbdb4d9d7fddda102180181',1,'com::shephertz::app42::paas::sdk::csharp::user::User']]]
];
