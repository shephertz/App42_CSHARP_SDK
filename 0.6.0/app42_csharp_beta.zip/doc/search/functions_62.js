var searchData=
[
  ['buildrecommender',['BuildRecommender',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1csharp_1_1_service_a_p_i.html#a0f0f54186829f655967dec5b40ada363',1,'com::shephertz::app42::paas::sdk::csharp::ServiceAPI']]],
  ['buildreview',['BuildReview',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1csharp_1_1_service_a_p_i.html#aa5f4e864efb9380ce734ca887ac13284',1,'com::shephertz::app42::paas::sdk::csharp::ServiceAPI']]],
  ['buildsessionmanager',['BuildSessionManager',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1csharp_1_1_service_a_p_i.html#a8ba299a4f665a4e60ec02512540a760c',1,'com::shephertz::app42::paas::sdk::csharp::ServiceAPI']]],
  ['buildupload',['BuildUpload',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1csharp_1_1_service_a_p_i.html#a6e94bba6b55504d6a745f132d059d85b',1,'com::shephertz::app42::paas::sdk::csharp::ServiceAPI']]],
  ['builduser',['BuildUser',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1csharp_1_1_service_a_p_i.html#ace28342cb338477c9e6ce6b8e0bf3970',1,'com::shephertz::app42::paas::sdk::csharp::ServiceAPI']]]
];
