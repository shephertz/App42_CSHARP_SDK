var searchData=
[
  ['invalidate',['Invalidate',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1csharp_1_1session_1_1_session_manager.html#a98035ead1505a479395e6fb344a47a8a',1,'com::shephertz::app42::paas::sdk::csharp::session::SessionManager']]],
  ['itembased',['ItemBased',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1csharp_1_1recommend_1_1_recommender.html#a4e8e839957e8ed95dd168ddef13f66bc',1,'com::shephertz::app42::paas::sdk::csharp::recommend::Recommender']]],
  ['itembasedbysimilarity',['ItemBasedBySimilarity',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1csharp_1_1recommend_1_1_recommender.html#ad8eb5d6de92af932db9bc7e27d196a9b',1,'com::shephertz::app42::paas::sdk::csharp::recommend::Recommender']]],
  ['itembasedbysimilarityforall',['ItemBasedBySimilarityForAll',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1csharp_1_1recommend_1_1_recommender.html#a00099faa4c063645ee0cebf6e0d53332',1,'com::shephertz::app42::paas::sdk::csharp::recommend::Recommender']]],
  ['itembasedforall',['ItemBasedForAll',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1csharp_1_1recommend_1_1_recommender.html#ac37a945d24a76d786924e5a2ba36f771',1,'com::shephertz::app42::paas::sdk::csharp::recommend::Recommender']]]
];
