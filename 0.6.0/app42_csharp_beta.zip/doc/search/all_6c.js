var searchData=
[
  ['loadpreferencefile',['LoadPreferenceFile',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1csharp_1_1recommend_1_1_recommender.html#ac65e03005dd8daf34406fe3988c91d22',1,'com::shephertz::app42::paas::sdk::csharp::recommend::Recommender']]],
  ['lockuser',['LockUser',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1csharp_1_1user_1_1_user.html#ac84616409fa860d47d541c1a408a9025',1,'com::shephertz::app42::paas::sdk::csharp::user::User']]]
];
