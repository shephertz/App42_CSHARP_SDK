var searchData=
[
  ['recommender',['Recommender',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1csharp_1_1recommend_1_1_recommender.html',1,'com::shephertz::app42::paas::sdk::csharp::recommend']]],
  ['recommendersimilarity',['RecommenderSimilarity',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1csharp_1_1recommend_1_1_recommender_similarity.html',1,'com::shephertz::app42::paas::sdk::csharp::recommend']]],
  ['restconnector',['RESTConnector',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1csharp_1_1connection_1_1_r_e_s_t_connector.html',1,'com::shephertz::app42::paas::sdk::csharp::connection']]],
  ['review',['Review',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1csharp_1_1review_1_1_review.html',1,'com::shephertz::app42::paas::sdk::csharp::review']]]
];
