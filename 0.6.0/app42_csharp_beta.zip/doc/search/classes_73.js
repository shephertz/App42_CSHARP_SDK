var searchData=
[
  ['serviceapi',['ServiceAPI',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1csharp_1_1_service_a_p_i.html',1,'com::shephertz::app42::paas::sdk::csharp']]],
  ['sessionmanager',['SessionManager',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1csharp_1_1session_1_1_session_manager.html',1,'com::shephertz::app42::paas::sdk::csharp::session']]]
];
