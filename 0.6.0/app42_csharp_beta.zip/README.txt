//App42 C# SDK
1. UnZip the downloaded file
2. This will contain App42_CSharp_SDK_0.6.0.dll ,doc, sample folder and README.txt
3. doc folder contains API docs
4. Sample folder contains Visual Studio C# sample project for using App42 C# SDK.
5. You need to put App42_CSharp_SDK_0.6.0.dll in classpath of your Project to use this.
6. Please visit http://apps.shephertz.com/CloudAPI/cloudapidocs/index.php for detail documentaion.