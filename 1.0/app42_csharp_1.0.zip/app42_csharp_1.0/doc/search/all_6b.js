var searchData=
[
  ['kb',['KB',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1csharp_1_1app_tab_1_1_bandwidth_unit.html#ae4ffe62f48b75c6116b4729f475f3bd8',1,'com.shephertz.app42.paas.sdk.csharp.appTab.BandwidthUnit.KB()'],['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1csharp_1_1app_tab_1_1_storage_unit.html#ac94eb73085831aa73012522e1ae51e91',1,'com.shephertz.app42.paas.sdk.csharp.appTab.StorageUnit.KB()']]]
];
