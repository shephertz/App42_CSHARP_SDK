var searchData=
[
  ['validatehowmany',['ValidateHowMany',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1csharp_1_1util_1_1_util.html#a54f423333022dafb52b15c7289129ae6',1,'com::shephertz::app42::paas::sdk::csharp::util::Util']]],
  ['validatemax',['ValidateMax',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1csharp_1_1util_1_1_util.html#a86e3d4c6614e9f2554d3db6c795a2343',1,'com::shephertz::app42::paas::sdk::csharp::util::Util']]],
  ['validatepackageusage',['ValidatePackageUsage',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1csharp_1_1app_tab_1_1_charge_service.html#a3cca5d8a9a708c3ed9fc3d4a7f2ced6a',1,'com::shephertz::app42::paas::sdk::csharp::appTab::ChargeService']]],
  ['value',['value',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1csharp_1_1game_1_1_game_1_1_score.html#add3845b0a9756c03f108c8ea7cbc37db',1,'com.shephertz.app42.paas.sdk.csharp.game.Game.Score.value()'],['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1csharp_1_1recommend_1_1_recommender_1_1_recommended_item.html#a0957885fa85bfcd483f1f06106c031fe',1,'com.shephertz.app42.paas.sdk.csharp.recommend.Recommender.RecommendedItem.value()'],['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1csharp_1_1session_1_1_session_1_1_attribute.html#a7c6850e4d0538774218c8ec5f710a073',1,'com.shephertz.app42.paas.sdk.csharp.session.Session.Attribute.value()']]],
  ['video',['VIDEO',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1csharp_1_1upload_1_1_upload_file_type.html#a1ead75b09ee7b0dc734b5ced2dc823cf',1,'com::shephertz::app42::paas::sdk::csharp::upload::UploadFileType']]]
];
